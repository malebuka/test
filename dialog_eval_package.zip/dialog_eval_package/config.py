OLLAMA_URL = "http://localhost:11434/api/chat"
JUDGE_MODEL = "qwen3:8b"

NUM_CTX = 32768
NUM_PREDICT_ALGORITHM = 1200
NUM_PREDICT_GENERATION = 700

GRAPH_FILE = "data/graph_dialogs.json"
PROMPT_FILE = "data/prompt_dialogs.json"
SCENARIO_IDS_FILE = "scenario_ids.json"
SCENARIO_REFERENCE_FILE = "scenario_reference.json"
ALGORITHM_FILE = "algorithm.txt"

RESULTS_DIR = "results"

MAX_RETRIES = 2
