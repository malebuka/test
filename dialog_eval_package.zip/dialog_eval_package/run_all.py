import subprocess
import sys

def run(script):
    print("\n" + "=" * 100)
    print(f"RUNNING: {script}")
    print("=" * 100)
    subprocess.run([sys.executable, script], check=True)

if __name__ == "__main__":
    run("evaluate_algorithm.py")
    run("evaluate_generation.py")
    run("compare_results.py")
