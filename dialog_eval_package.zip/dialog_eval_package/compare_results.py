from pathlib import Path
import pandas as pd

from config import RESULTS_DIR

def paired_table(df, value_col):
    pivot = df.pivot(index="scenario_id", columns="system", values=value_col).dropna()

    if "graph" not in pivot.columns or "prompt" not in pivot.columns:
        raise ValueError(f"Для {value_col} нужны обе системы: graph и prompt.")

    pivot["delta_graph_minus_prompt"] = pivot["graph"] - pivot["prompt"]
    return pivot

def main():
    results = Path(RESULTS_DIR)

    alg_path = results / "algorithm_dialogs.csv"
    gen_path = results / "generation_dialogs.csv"

    if alg_path.exists():
        alg = pd.read_csv(alg_path)

        print("\nPAIRED: ALGORITHM ADHERENCE")
        paired = paired_table(alg, "algorithm_adherence")
        print(paired.round(2).to_string())
        print("\nMean paired delta:",
              round(paired["delta_graph_minus_prompt"].mean(), 2))
        paired.to_csv(
            results / "paired_algorithm_adherence.csv",
            encoding="utf-8-sig",
        )

        print("\nBY CATEGORY: ALGORITHM")
        by_cat = (
            alg.groupby(["category", "system"])
            ["algorithm_adherence"]
            .mean()
            .unstack("system")
        )
        if "graph" in by_cat.columns and "prompt" in by_cat.columns:
            by_cat["delta_graph_minus_prompt"] = by_cat["graph"] - by_cat["prompt"]

        print(by_cat.round(2).to_string())
        by_cat.to_csv(
            results / "algorithm_by_category.csv",
            encoding="utf-8-sig",
        )

    if gen_path.exists():
        gen = pd.read_csv(gen_path)

        print("\nPAIRED: RESPONSE INTEGRITY")
        paired = paired_table(gen, "response_integrity_score")
        print(paired.round(2).to_string())
        print("\nMean paired delta:",
              round(paired["delta_graph_minus_prompt"].mean(), 2))
        paired.to_csv(
            results / "paired_generation_integrity.csv",
            encoding="utf-8-sig",
        )

if __name__ == "__main__":
    main()
