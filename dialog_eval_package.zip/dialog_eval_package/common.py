import json
import re
from pathlib import Path

def load_json(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)

def normalize_dialogs(raw, scenario_ids):
    """
    Поддерживает:
    1) list[list[{role, content}]]
    2) list[{"scenario_id": "...", "messages": [...]}]
    """
    if not isinstance(raw, list):
        raise ValueError("Файл диалогов должен содержать список.")

    if not raw:
        return []

    first = raw[0]

    if isinstance(first, dict) and "messages" in first:
        result = []
        for item in raw:
            result.append({
                "scenario_id": item["scenario_id"],
                "messages": item["messages"],
            })
        return result

    if isinstance(first, list):
        if len(raw) != len(scenario_ids):
            raise ValueError(
                f"Число диалогов ({len(raw)}) не совпадает с числом scenario_ids ({len(scenario_ids)})."
            )
        return [
            {"scenario_id": sid, "messages": dialog}
            for sid, dialog in zip(scenario_ids, raw)
        ]

    raise ValueError("Неизвестный формат диалогов.")

def format_dialog(messages):
    lines = []
    for message in messages:
        role = message.get("role")
        content = str(message.get("content", "")).strip()

        if role == "assistant":
            speaker = "AGENT"
        elif role in ("user", "client"):
            speaker = "CLIENT"
        else:
            continue

        lines.append(f"{speaker}: {content}")

    return "\n".join(lines)

def format_history(messages):
    text = format_dialog(messages)
    return text if text else "История отсутствует."

def extract_json(text):
    text = text.strip()

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    text = re.sub(r"```(?:json)?", "", text, flags=re.IGNORECASE)
    text = text.replace("```", "").strip()

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass

    start = text.find("{")
    end = text.rfind("}")

    if start == -1 or end == -1 or end <= start:
        raise ValueError(f"Judge returned invalid JSON:\n{text}")

    return json.loads(text[start:end + 1])

def ensure_results_dir(path):
    Path(path).mkdir(parents=True, exist_ok=True)
