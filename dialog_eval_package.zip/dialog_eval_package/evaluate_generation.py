import pandas as pd
import requests
from pathlib import Path

from config import (
    OLLAMA_URL,
    JUDGE_MODEL,
    NUM_CTX,
    NUM_PREDICT_GENERATION,
    GRAPH_FILE,
    PROMPT_FILE,
    SCENARIO_IDS_FILE,
    RESULTS_DIR,
    MAX_RETRIES,
)
from common import (
    load_json,
    normalize_dialogs,
    format_history,
    extract_json,
    ensure_results_dir,
)

ERROR_COLUMNS = [
    "repetition",
    "grammar",
    "lexical_anomaly",
    "coherence",
    "template_degeneration",
    "context_hallucination",
    "unsupported_claim",
]

WEIGHTS = {
    "repetition": 1,
    "grammar": 1,
    "lexical_anomaly": 1,
    "coherence": 2,
    "template_degeneration": 1,
    "context_hallucination": 3,
    "unsupported_claim": 3,
}

MAX_WEIGHTED_ERROR = 3 * sum(WEIGHTS.values())

JUDGE_SYSTEM = """
Ты независимый evaluator качества генерации диалогового агента.

Тебе дана история диалога и один конкретный ответ AGENT.
Не оценивай соблюдение бизнес-алгоритма и правильность выбранной стратегии.
Оценивай только качество текста и наличие выдуманной информации.

Каждая категория:
0 = ошибки нет
1 = небольшая ошибка
2 = заметная ошибка
3 = серьезная ошибка

repetition:
ненужные повторы слов, фраз, предложений или одной и той же мысли.

grammar:
неправильные окончания, падежи, род, число, согласование,
формы глагола или сломанная грамматическая конструкция.

lexical_anomaly:
несуществующие, поврежденные, неправильные или явно неуместные слова/словоформы.

coherence:
нарушение связности, внутренние противоречия, бессмысленные фрагменты,
оборванные предложения или нелогичные переходы.

template_degeneration:
механическое повторение одинаковых конструкций, зацикливание,
чрезмерное шаблонное копирование предыдущих ответов.

context_hallucination:
агент приписывает клиенту информацию, которой клиент не сообщал.

unsupported_claim:
агент утверждает как установленный факт информацию, не подтвержденную диалогом:
выдуманные договоренности, суммы, сроки, действия клиента и т.п.

reason:
максимум 2 коротких предложения.
Если дефектов нет: "Существенных дефектов не обнаружено."

Верни только JSON:

{
  "repetition": 0,
  "grammar": 0,
  "lexical_anomaly": 0,
  "coherence": 0,
  "template_degeneration": 0,
  "context_hallucination": 0,
  "unsupported_claim": 0,
  "reason": "..."
}

Никакого markdown и текста вне JSON.
"""

def call_judge(history, target_response):
    history_text = format_history(history)

    prompt = f"""
ИСТОРИЯ ДО ОЦЕНИВАЕМОГО ОТВЕТА:

========================
{history_text}
========================

ОЦЕНИВАЕМЫЙ ОТВЕТ AGENT:

========================
{target_response}
========================

Оцени только указанный ответ.
Историю используй для выявления повторов, шаблонной деградации,
контекстных галлюцинаций и неподтвержденных утверждений.
Верни только JSON.
"""

    last_error = None

    for attempt in range(MAX_RETRIES + 1):
        payload = {
            "model": JUDGE_MODEL,
            "messages": [
                {"role": "system", "content": JUDGE_SYSTEM},
                {"role": "user", "content": prompt},
            ],
            "stream": False,
            "think": False,
            "format": "json",
            "options": {
                "temperature": 0,
                "num_ctx": NUM_CTX,
                "num_predict": NUM_PREDICT_GENERATION,
            },
        }

        response = requests.post(OLLAMA_URL, json=payload, timeout=300)
        response.raise_for_status()
        data = response.json()
        content = data["message"]["content"]

        try:
            result = extract_json(content)

            for field in ERROR_COLUMNS:
                if field not in result:
                    raise ValueError(f"Missing field: {field}")
                result[field] = max(0, min(3, int(result[field])))

            result["reason"] = str(result.get("reason", ""))
            return result

        except Exception as e:
            last_error = e
            print(f"JSON error attempt {attempt + 1}/{MAX_RETRIES + 1}: {e}")
            print("RAW:", repr(content))
            print("done_reason:", data.get("done_reason"))

    raise last_error

def integrity_score(result):
    weighted_error = sum(
        int(result.get(name, 0)) * weight
        for name, weight in WEIGHTS.items()
    )
    score = 100 * (1 - weighted_error / MAX_WEIGHTED_ERROR)
    return max(0, min(100, score))

def evaluate_dialog(messages, system_name, scenario_id):
    rows = []
    assistant_turn = 0

    for idx, message in enumerate(messages):
        if message.get("role") != "assistant":
            continue

        assistant_turn += 1
        target = str(message.get("content", ""))
        history = messages[:idx]

        print(f"[{system_name}] scenario={scenario_id} turn={assistant_turn}")

        try:
            result = call_judge(history, target)

            clean = int(all(result[name] == 0 for name in ERROR_COLUMNS))
            hallucination = int(
                result["context_hallucination"] > 0
                or result["unsupported_claim"] > 0
            )

            row = {
                "system": system_name,
                "scenario_id": scenario_id,
                "assistant_turn": assistant_turn,
                "response_integrity_score": integrity_score(result),
                "clean_response": clean,
                "hallucination": hallucination,
                "reason": result.get("reason", ""),
            }

            for name in ERROR_COLUMNS:
                row[name] = result[name]

            rows.append(row)

        except Exception as e:
            print(
                f"ERROR [{system_name}] scenario={scenario_id} "
                f"turn={assistant_turn}: {e}"
            )

    return rows

def evaluate_system(dialogs, system_name):
    rows = []

    for i, item in enumerate(dialogs, 1):
        sid = item["scenario_id"]
        print(f"\n[{system_name}] dialog {i}/{len(dialogs)} {sid}")
        rows.extend(
            evaluate_dialog(
                messages=item["messages"],
                system_name=system_name,
                scenario_id=sid,
            )
        )

    return rows

def main():
    ensure_results_dir(RESULTS_DIR)

    scenario_ids = load_json(SCENARIO_IDS_FILE)
    graph = normalize_dialogs(load_json(GRAPH_FILE), scenario_ids)
    prompt = normalize_dialogs(load_json(PROMPT_FILE), scenario_ids)

    rows = []
    rows += evaluate_system(graph, "graph")
    rows += evaluate_system(prompt, "prompt")

    df = pd.DataFrame(rows)

    if df.empty:
        raise RuntimeError("Не удалось оценить ни одного ответа.")

    out_turns = Path(RESULTS_DIR) / "generation_turns.csv"
    df.to_csv(out_turns, index=False, encoding="utf-8-sig")

    dialog_rows = []

    for (system, scenario_id), group in df.groupby(["system", "scenario_id"]):
        row = {
            "system": system,
            "scenario_id": scenario_id,
            "responses": len(group),
            "response_integrity_score": group["response_integrity_score"].mean(),
            "clean_response_rate": group["clean_response"].mean() * 100,
            "hallucination_rate": group["hallucination"].mean() * 100,
        }

        for error in ERROR_COLUMNS:
            row[f"{error}_rate"] = (group[error] > 0).mean() * 100

        dialog_rows.append(row)

    dialog_df = pd.DataFrame(dialog_rows)
    out_dialogs = Path(RESULTS_DIR) / "generation_dialogs.csv"
    dialog_df.to_csv(out_dialogs, index=False, encoding="utf-8-sig")

    summary = (
        df.groupby("system")
        .agg(
            responses=("assistant_turn", "count"),
            response_integrity_score=("response_integrity_score", "mean"),
            integrity_std=("response_integrity_score", "std"),
            clean_response_rate=("clean_response", "mean"),
            hallucination_rate=("hallucination", "mean"),
        )
    )

    summary["clean_response_rate"] *= 100
    summary["hallucination_rate"] *= 100

    for error in ERROR_COLUMNS:
        rates = (
            df.assign(error_present=(df[error] > 0).astype(int))
            .groupby("system")["error_present"]
            .mean()
            * 100
        )
        summary[f"{error}_rate"] = rates

    out_summary = Path(RESULTS_DIR) / "generation_summary.csv"
    summary.to_csv(out_summary, encoding="utf-8-sig")

    print("\nGENERATION QUALITY SUMMARY")
    print(summary.round(2).to_string())

if __name__ == "__main__":
    main()
