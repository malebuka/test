import json
from pathlib import Path

import pandas as pd
import requests

from config import (
    OLLAMA_URL,
    JUDGE_MODEL,
    NUM_CTX,
    NUM_PREDICT_ALGORITHM,
    GRAPH_FILE,
    PROMPT_FILE,
    SCENARIO_IDS_FILE,
    SCENARIO_REFERENCE_FILE,
    ALGORITHM_FILE,
    RESULTS_DIR,
    MAX_RETRIES,
)
from common import (
    load_json,
    normalize_dialogs,
    format_dialog,
    extract_json,
    ensure_results_dir,
)

JUDGE_SYSTEM = """
Ты независимый evaluator диалогового агента.

Оценивай только наблюдаемое поведение агента.
Не учитывай, какая архитектура использовалась.
Не оценивай красоту текста и стиль.

Поставь оценки от 0 до 100:

sequence_score:
насколько правильно соблюден требуемый порядок действий.

required_steps_score:
насколько полно выполнены обязательные шаги.

transition_score:
насколько корректно агент переходит от шага к шагу и не делает
преждевременных переходов.

context_score:
насколько действия агента соответствуют ответам клиента и контексту.

scenario_success:
true, если конкретный сценарий завершен в соответствии с success_condition.

critical_error:
true, если есть хотя бы одна критическая ошибка.

critical_errors:
максимум 5 коротких пунктов.

reason:
краткое объяснение оценки, максимум 2 предложения.

К критическим ошибкам относятся:
- ложное согласие;
- ложный отказ;
- пропуск ключевого обязательного шага;
- серьезное нарушение последовательности;
- переход в неверную ветку;
- преждевременное завершение;
- фиксация несуществующей договоренности;
- действие, противоречащее явному ответу клиента;
- запрещенное раскрытие информации третьему лицу.

Верни только валидный JSON:

{
  "sequence_score": 0,
  "required_steps_score": 0,
  "transition_score": 0,
  "context_score": 0,
  "scenario_success": false,
  "critical_error": false,
  "critical_errors": [],
  "reason": "..."
}

Никакого markdown и текста вне JSON.
"""

def call_judge(algorithm, scenario_id, scenario_ref, messages):
    dialog_text = format_dialog(messages)

    prompt = f"""
ОБЩИЙ ЭТАЛОННЫЙ АЛГОРИТМ:

========================
{algorithm}
========================

КОНКРЕТНЫЙ СЦЕНАРИЙ:
{scenario_id}

КАТЕГОРИЯ:
{scenario_ref["category"]}

ОЖИДАЕМОЕ ПОВЕДЕНИЕ:
{json.dumps(scenario_ref["expected_behavior"], ensure_ascii=False, indent=2)}

ЗАПРЕЩЕННЫЕ / НЕЖЕЛАТЕЛЬНЫЕ ДЕЙСТВИЯ:
{json.dumps(scenario_ref["forbidden_actions"], ensure_ascii=False, indent=2)}

УСЛОВИЕ УСПЕХА:
{scenario_ref["success_condition"]}

ДИАЛОГ:

========================
{dialog_text}
========================

Оцени диалог целиком.
Верни только JSON заданного формата.
"""

    last_error = None

    for attempt in range(MAX_RETRIES + 1):
        payload = {
            "model": JUDGE_MODEL,
            "messages": [
                {"role": "system", "content": JUDGE_SYSTEM},
                {"role": "user", "content": prompt},
            ],
            "stream": False,
            "think": False,
            "format": "json",
            "options": {
                "temperature": 0,
                "num_ctx": NUM_CTX,
                "num_predict": NUM_PREDICT_ALGORITHM,
            },
        }

        response = requests.post(OLLAMA_URL, json=payload, timeout=300)
        response.raise_for_status()
        data = response.json()
        content = data["message"]["content"]

        try:
            result = extract_json(content)

            for key in [
                "sequence_score",
                "required_steps_score",
                "transition_score",
                "context_score",
                "scenario_success",
                "critical_error",
                "critical_errors",
                "reason",
            ]:
                if key not in result:
                    raise ValueError(f"Missing key: {key}")

            for key in [
                "sequence_score",
                "required_steps_score",
                "transition_score",
                "context_score",
            ]:
                result[key] = max(0, min(100, float(result[key])))

            return result

        except Exception as e:
            last_error = e
            print(f"JSON error attempt {attempt + 1}/{MAX_RETRIES + 1}: {e}")
            print("RAW:", repr(content))
            print("done_reason:", data.get("done_reason"))

    raise last_error

def total_score(result):
    return (
        result["sequence_score"]
        + result["required_steps_score"]
        + result["transition_score"]
        + result["context_score"]
    ) / 4

def evaluate_system(dialogs, system_name, algorithm, refs):
    rows = []

    for i, item in enumerate(dialogs, 1):
        sid = item["scenario_id"]
        messages = item["messages"]

        print(f"[{system_name}] {i}/{len(dialogs)} scenario={sid}")

        try:
            result = call_judge(
                algorithm=algorithm,
                scenario_id=sid,
                scenario_ref=refs[sid],
                messages=messages,
            )

            rows.append({
                "system": system_name,
                "scenario_id": sid,
                "category": refs[sid]["category"],
                "algorithm_adherence": total_score(result),
                "sequence_score": result["sequence_score"],
                "required_steps_score": result["required_steps_score"],
                "transition_score": result["transition_score"],
                "context_score": result["context_score"],
                "scenario_success": int(bool(result["scenario_success"])),
                "critical_error": int(bool(result["critical_error"])),
                "critical_errors": " | ".join(result.get("critical_errors", [])),
                "reason": result.get("reason", ""),
            })

        except Exception as e:
            print(f"ERROR [{system_name}] scenario={sid}: {e}")

    return rows

def main():
    ensure_results_dir(RESULTS_DIR)

    algorithm = Path(ALGORITHM_FILE).read_text(encoding="utf-8")
    scenario_ids = load_json(SCENARIO_IDS_FILE)
    refs = load_json(SCENARIO_REFERENCE_FILE)

    graph = normalize_dialogs(load_json(GRAPH_FILE), scenario_ids)
    prompt = normalize_dialogs(load_json(PROMPT_FILE), scenario_ids)

    rows = []
    rows += evaluate_system(graph, "graph", algorithm, refs)
    rows += evaluate_system(prompt, "prompt", algorithm, refs)

    df = pd.DataFrame(rows)

    if df.empty:
        raise RuntimeError("Не удалось оценить ни одного диалога.")

    out_dialogs = Path(RESULTS_DIR) / "algorithm_dialogs.csv"
    df.to_csv(out_dialogs, index=False, encoding="utf-8-sig")

    summary = (
        df.groupby("system")
        .agg(
            dialogs=("scenario_id", "count"),
            algorithm_adherence=("algorithm_adherence", "mean"),
            adherence_std=("algorithm_adherence", "std"),
            sequence_score=("sequence_score", "mean"),
            required_steps_score=("required_steps_score", "mean"),
            transition_score=("transition_score", "mean"),
            context_score=("context_score", "mean"),
            scenario_success_rate=("scenario_success", "mean"),
            critical_error_rate=("critical_error", "mean"),
            critical_error_count=("critical_error", "sum"),
        )
    )

    summary["scenario_success_rate"] *= 100
    summary["critical_error_rate"] *= 100

    out_summary = Path(RESULTS_DIR) / "algorithm_summary.csv"
    summary.to_csv(out_summary, encoding="utf-8-sig")

    print("\nALGORITHM SUMMARY")
    print(summary.round(2).to_string())

if __name__ == "__main__":
    main()
