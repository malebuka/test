# Dialog Agent Evaluation Package

Пакет для сравнения двух версий чатбота:

- `graph` — графовая версия (LangGraph / intents / явная логика переходов)
- `prompt` — старая версия с одним большим системным промптом

Оценка разделена на два независимых блока:

1. **Dialogue Policy / Algorithm Adherence**
   - соблюдение обязательных шагов;
   - правильный порядок;
   - отсутствие преждевременных переходов;
   - работа с ответами клиента;
   - критические ошибки;
   - успешность прохождения конкретного сценария.

2. **Generation Quality**
   - повторы;
   - грамматика;
   - лексические аномалии;
   - связность;
   - шаблонная деградация;
   - контекстные галлюцинации;
   - неподтвержденные утверждения.

## 1. Установка

```bash
pip install -r requirements.txt
```

Ollama должна быть запущена отдельно.

Пример:

```bash
ollama serve
ollama pull qwen3:8b
```

Модель можно поменять в `config.py`.

---

## 2. Входные данные

Положите свои два файла в папку `data/`:

```text
data/graph_dialogs.json
data/prompt_dialogs.json
```

Поддерживаются два формата.

### Формат A — обычный список диалогов

```json
[
  [
    {"role": "assistant", "content": "Здравствуйте..."},
    {"role": "user", "content": "Сейчас денег нет"},
    {"role": "assistant", "content": "Сможете оплатить в течение трех дней?"}
  ],
  [
    {"role": "assistant", "content": "..."},
    {"role": "user", "content": "..."}
  ]
]
```

Если используется этот формат, порядок диалогов должен совпадать с
`scenario_ids.json`.

### Формат B — с scenario_id

```json
[
  {
    "scenario_id": "B01",
    "messages": [
      {"role": "assistant", "content": "..."},
      {"role": "user", "content": "..."}
    ]
  }
]
```

Этот формат предпочтительнее.

---

## 3. Сценарии

В `scenario_reference.json` лежит эталон для 42 сценариев.

Стандартные:
- B01-B03 — согласие на оплату в течение 3 дней
- B04-B06 — согласие на помощь родственников
- B07-B09 — согласие на частичную оплату
- B10-B12 — согласие на реструктуризацию
- B13-B15 — согласие на реализацию залога
- B16-B18 — отказ от всех вариантов

Специальные:
- BK01-BK03 — банкротство
- TR01-TR03 — командировка
- TECH01-TECH03 — техническая проблема
- ILL01-ILL03 — болезнь
- PAID01-PAID03 — уже оплатил
- DEAD01-DEAD03 — клиент умер
- SVO01-SVO03 — клиент на СВО
- TP01-TP03 — третье лицо

---

## 4. Запуск

### Только следование алгоритму

```bash
python evaluate_algorithm.py
```

Результаты:

```text
results/algorithm_dialogs.csv
results/algorithm_summary.csv
```

### Только качество генерации

```bash
python evaluate_generation.py
```

Результаты:

```text
results/generation_turns.csv
results/generation_dialogs.csv
results/generation_summary.csv
```

### Полный запуск

```bash
python run_all.py
```

### Парное сравнение Graph vs Prompt

После запуска evaluator-ов:

```bash
python compare_results.py
```

Он рассчитает разницу внутри каждой пары одинаковых сценариев.

---

## 5. Как читать метрики

### Dialogue Policy

Больше лучше:
- `algorithm_adherence`
- `sequence_score`
- `required_steps_score`
- `transition_score`
- `context_score`
- `scenario_success_rate`

Меньше лучше:
- `critical_error_rate`

### Generation Quality

Больше лучше:
- `response_integrity_score`
- `clean_response_rate`

Меньше лучше:
- `integrity_std`
- `hallucination_rate`
- `repetition_rate`
- `grammar_rate`
- `lexical_anomaly_rate`
- `coherence_rate`
- `template_degeneration_rate`
- `context_hallucination_rate`
- `unsupported_claim_rate`

---

## 6. Важный принцип эксперимента

Для Graph и Prompt должны использоваться одни и те же сценарии.

Сравнивайте попарно:

```text
B01 Graph  vs B01 Prompt
B02 Graph  vs B02 Prompt
...
TP03 Graph vs TP03 Prompt
```

Judge не получает информацию о том, какая архитектура породила диалог.
